import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectcategory',
  templateUrl: './selectcategory.page.html',
  styleUrls: ['./selectcategory.page.scss'],
})
export class SelectcategoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
