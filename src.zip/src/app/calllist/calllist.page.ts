import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calllist',
  templateUrl: './calllist.page.html',
  styleUrls: ['./calllist.page.scss'],
})
export class CalllistPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
