import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectservice',
  templateUrl: './selectservice.page.html',
  styleUrls: ['./selectservice.page.scss'],
})
export class SelectservicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
