import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addqr',
  templateUrl: './addqr.page.html',
  styleUrls: ['./addqr.page.scss'],
})
export class AddqrPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
