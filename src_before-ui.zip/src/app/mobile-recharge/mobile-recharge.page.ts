import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-recharge',
  templateUrl: './mobile-recharge.page.html',
  styleUrls: ['./mobile-recharge.page.scss'],
})
export class MobileRechargePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
