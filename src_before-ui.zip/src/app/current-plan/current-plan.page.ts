import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-plan',
  templateUrl: './current-plan.page.html',
  styleUrls: ['./current-plan.page.scss'],
})
export class CurrentPlanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
