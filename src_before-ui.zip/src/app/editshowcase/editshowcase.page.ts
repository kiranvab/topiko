import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editshowcase',
  templateUrl: './editshowcase.page.html',
  styleUrls: ['./editshowcase.page.scss'],
})
export class EditshowcasePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
