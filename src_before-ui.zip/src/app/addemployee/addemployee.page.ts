import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.page.html',
  styleUrls: ['./addemployee.page.scss'],
})
export class AddemployeePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
