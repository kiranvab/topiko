import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  // iconcolor = "#ffffffbd";
  // change = true;
  // public footerIconColor() {
  //   this.iconcolor = "#ffffff";
  // }

}
