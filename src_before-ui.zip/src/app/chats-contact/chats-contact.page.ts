import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chats-contact',
  templateUrl: './chats-contact.page.html',
  styleUrls: ['./chats-contact.page.scss'],
})
export class ChatsContactPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
