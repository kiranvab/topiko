import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editdvdetails',
  templateUrl: './editdvdetails.page.html',
  styleUrls: ['./editdvdetails.page.scss'],
})
export class EditdvdetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
