import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-chats',
  templateUrl: './company-chats.page.html',
  styleUrls: ['./company-chats.page.scss'],
})
export class CompanyChatsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
