import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-businesses-service',
  templateUrl: './businesses-service.page.html',
  styleUrls: ['./businesses-service.page.scss'],
})
export class BusinessesServicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
