import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addoffers',
  templateUrl: './addoffers.page.html',
  styleUrls: ['./addoffers.page.scss'],
})
export class AddoffersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
