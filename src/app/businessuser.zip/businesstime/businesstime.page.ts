import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-businesstime',
  templateUrl: './businesstime.page.html',
  styleUrls: ['./businesstime.page.scss'],
})
export class BusinesstimePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
