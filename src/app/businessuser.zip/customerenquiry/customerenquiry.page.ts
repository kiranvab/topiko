import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerenquiry',
  templateUrl: './customerenquiry.page.html',
  styleUrls: ['./customerenquiry.page.scss'],
})
export class CustomerenquiryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
