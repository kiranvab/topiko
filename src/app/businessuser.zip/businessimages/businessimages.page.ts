import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-businessimages',
  templateUrl: './businessimages.page.html',
  styleUrls: ['./businessimages.page.scss'],
})
export class BusinessimagesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
