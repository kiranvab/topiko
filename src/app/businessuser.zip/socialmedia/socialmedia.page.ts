import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-socialmedia',
  templateUrl: './socialmedia.page.html',
  styleUrls: ['./socialmedia.page.scss'],
})
export class SocialmediaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
