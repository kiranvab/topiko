import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enquiries',
  templateUrl: './enquiries.page.html',
  styleUrls: ['./enquiries.page.scss'],
})
export class EnquiriesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
