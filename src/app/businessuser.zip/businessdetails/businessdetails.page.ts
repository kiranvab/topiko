import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-businessdetails',
  templateUrl: './businessdetails.page.html',
  styleUrls: ['./businessdetails.page.scss'],
})
export class BusinessdetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
