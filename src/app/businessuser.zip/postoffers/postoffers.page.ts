import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postoffers',
  templateUrl: './postoffers.page.html',
  styleUrls: ['./postoffers.page.scss'],
})
export class PostoffersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
