import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-businesscategory',
  templateUrl: './businesscategory.page.html',
  styleUrls: ['./businesscategory.page.scss'],
})
export class BusinesscategoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
