import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productcategory',
  templateUrl: './productcategory.page.html',
  styleUrls: ['./productcategory.page.scss'],
})
export class ProductcategoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
