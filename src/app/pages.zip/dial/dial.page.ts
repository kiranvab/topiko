import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dial',
  templateUrl: './dial.page.html',
  styleUrls: ['./dial.page.scss'],
})
export class DialPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
