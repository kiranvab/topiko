import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-details',
  templateUrl: './plan-details.page.html',
  styleUrls: ['./plan-details.page.scss'],
})
export class PlanDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
