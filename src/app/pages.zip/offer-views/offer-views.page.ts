import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-views',
  templateUrl: './offer-views.page.html',
  styleUrls: ['./offer-views.page.scss'],
})
export class OfferViewsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
