import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-bills',
  templateUrl: './pay-bills.page.html',
  styleUrls: ['./pay-bills.page.scss'],
})
export class PayBillsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
