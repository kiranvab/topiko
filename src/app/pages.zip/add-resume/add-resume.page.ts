import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-resume',
  templateUrl: './add-resume.page.html',
  styleUrls: ['./add-resume.page.scss'],
})
export class AddResumePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
