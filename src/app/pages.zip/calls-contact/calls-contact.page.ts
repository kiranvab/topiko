import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calls-contact',
  templateUrl: './calls-contact.page.html',
  styleUrls: ['./calls-contact.page.scss'],
})
export class CallsContactPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
