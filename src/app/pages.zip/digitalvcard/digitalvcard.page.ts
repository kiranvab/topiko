import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-digitalvcard',
  templateUrl: './digitalvcard.page.html',
  styleUrls: ['./digitalvcard.page.scss'],
})
export class DigitalvcardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
