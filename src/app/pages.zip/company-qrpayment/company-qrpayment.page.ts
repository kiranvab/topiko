import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-qrpayment',
  templateUrl: './company-qrpayment.page.html',
  styleUrls: ['./company-qrpayment.page.scss'],
})
export class CompanyQrpaymentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
