import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-views',
  templateUrl: './product-views.page.html',
  styleUrls: ['./product-views.page.scss'],
})
export class ProductViewsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
