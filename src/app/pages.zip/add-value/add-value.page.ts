import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-value',
  templateUrl: './add-value.page.html',
  styleUrls: ['./add-value.page.scss'],
})
export class AddValuePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
